package com.hackerearth.practise;

public class dummy {

}
